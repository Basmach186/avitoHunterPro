from config import PRICE_LIMITS, BAD_WORDS


def check_card(title, price, text):
    """
    Возвращает:
    True, model — если объявление подходит
    False, None — если не подходит
    """

    title = title.lower()
    text = text.lower()

    full_text = title + " " + text

    # Проверка плохих слов
    for word in BAD_WORDS:
        if word in full_text:
            return False, None

    # Проверка модели (сначала самые длинные названия)
    models = sorted(
        PRICE_LIMITS.keys(),
        key=len,
        reverse=True
    )

    for model in models:

        if model in title:

            limit = PRICE_LIMITS[model]

            if price > limit:
                return False, None

            return True, model

    return False, None


def get_profit(model, price):
    """
    Возвращает экономию относительно лимита.
    """

    if model not in PRICE_LIMITS:
        return 0

    return PRICE_LIMITS[model] - price


def get_status(model, price):
    """
    Красивый статус объявления.
    """

    profit = get_profit(model, price)

    if profit >= 10000:
        return "💎 СУПЕР ЦЕНА"

    if profit >= 5000:
        return "🔥 ОЧЕНЬ ВЫГОДНО"

    if profit >= 2000:
        return "🟢 ВЫГОДНО"

    return "⚪ НОРМАЛЬНАЯ ЦЕНА"