import requests
from datetime import datetime
from config import BOT_TOKEN, CHAT_ID


def send(title, price, model, status, link):

    now = datetime.now().strftime("%H:%M:%S")

    text = f"""
{status}

📱 {title}

💰 Цена: {price:,} ₽

🚚 Авито Доставка

🔗 {link}

🕒 {now}
"""

    requests.post(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
        data={
            "chat_id": CHAT_ID,
            "text": text
        }
    )